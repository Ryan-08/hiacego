package com.example.tugashiace.model

data class Users(
    val id: String,
    val nama: String?,
    val email: String,
    val username: String,
    val nomorHp: String?
) {
    constructor():this("", "", "", "", "")
}