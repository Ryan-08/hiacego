package com.example.tugashiace.model

data class Travel (
    var Travel : String ?= null,
    var Jam : String ?= null,
    val Rute : String?=null,
    val Harga : String?=null,
    val Durasi : String?=null
)