package com.example.tugashiace

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tugashiace.`interface`.IFirebaseLoadDone
import com.example.tugashiace.controller.DataController
import com.example.tugashiace.databinding.FragmentBerandaBinding
import com.example.tugashiace.model.Mobil
import com.example.tugashiace.model.Rute
import com.example.tugashiace.model.Tiket
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.fragment_beranda.*
import kotlin.collections.ArrayList


class Beranda : Fragment(), IFirebaseLoadDone {
    //initial variabel
    private var _binding: FragmentBerandaBinding? = null
    private val binding get() = _binding!!
    private lateinit var ruteRef: DatabaseReference
    lateinit var iFirebaseLoadDone: IFirebaseLoadDone
    private var jmlPenumpang = 1
    private var tujuan : String = ""
    private var rute : String = ""
    private var tanggal : String = ""
    /*private lateinit var durasi : String
    private lateinit var harga : String*/


    //menampilkan beranda
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_beranda, container, false)
    }


    //mengambil data titik tujuan dan alamat loket dari Firebase
    override fun onFirebaseLoadSuccess(ruteList: List<Rute>) {
        //Get all names from id
        val ruteNameTitles = getRuteNameList (ruteList)
        val ruteAddress = getRuteAddressList (ruteList)
        val ruteState = getRuteStateList (ruteList)
        /*val rute_duration = getRuteDurationList (ruteList)
        val rute_fee = getRuteFeeList (ruteList)*/

        //create Adapter
        val adapter = ArrayAdapter<String>(requireContext(),android.R.layout.simple_list_item_1,ruteNameTitles)
        tvStateB.adapter = adapter

        tvStateB.onItemSelectedListener = object :

            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                tvAddressB.text = ruteAddress[position]

                val spinner: Spinner = tvStateB
                spinner.onItemSelectedListener = this

                tujuan = ruteState[position]
                rute = ruteNameTitles[position]
                /*durasi = rute_duration[position]
                harga = rute_fee[position]*/


            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

        }

    }

    private fun getRuteAddressList(ruteList: List<Rute>): List<String> {
        val result = ArrayList<String>()
        for(rute in ruteList)
            result.add(rute.Address!!)
        return result
    }

    private fun getRuteNameList(ruteList: List<Rute>): List<String> {
        val result = ArrayList<String>()
        for(rute in ruteList)
            result.add(rute.Key!!)
        return result
    }

    private fun getRuteStateList(ruteList: List<Rute>): List<String> {
        val result = ArrayList<String>()
        for(rute in ruteList)
            result.add(rute.State!!)
        return result
    }

    override fun onFirebaseLoadFailed(message: String) {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //init interface
        iFirebaseLoadDone = this
        //init DB
        ruteRef = FirebaseDatabase.getInstance().getReference("RUTE");
        //Load Data
        ruteRef.addValueEventListener(object:ValueEventListener{
            var ruteList:MutableList<Rute> = ArrayList()
            override fun onCancelled(error: DatabaseError) {
                iFirebaseLoadDone.onFirebaseLoadFailed(error.message)
            }

            override fun onDataChange(snapshot: DataSnapshot) {
                for(ruteSnapShot in snapshot.children)
                    ruteList.add(ruteSnapShot.getValue(Rute::class.java)!!)
                iFirebaseLoadDone.onFirebaseLoadSuccess(ruteList)
            }

        })


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentBerandaBinding.bind(view)



        binding.apply {
            val controller = DataController()
            val listData = MutableLiveData<List<Tiket>>()
            controller.getUserTiket(listData, "on progress")
//            controller.getUserTiket(listData)

            val tiketRecyclerView : RecyclerView = view.findViewById(R.id.recycler_view)
            tiketRecyclerView.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            tiketRecyclerView.setHasFixedSize(true)
            val adapter = BerandaAdapter()
            tiketRecyclerView.adapter = adapter

            listData.observe(viewLifecycleOwner){
                adapter.updateTiketList(it)
            }
            adapter.onItemClick = {
                val bundle = Bundle()
                bundle.putString("tiket", it.noTiket)
    //            bundle.putString("rute", rute)
                val newFragment = TiketSaya()
                newFragment.arguments = bundle

                activity?.supportFragmentManager?.beginTransaction()?.add(R.id.container, newFragment)?.commit()
            }
            //Choose date
            btnPickDate.setOnClickListener {
                val datePickerFragment = DatePickerFragment()
                val supportFragmentManager = requireActivity().supportFragmentManager

                supportFragmentManager.setFragmentResultListener(
                    "REQUEST_KEY",
                    viewLifecycleOwner
                )
                { resultKey, bundle ->
                    if (resultKey == "REQUEST_KEY") {
                        val date = bundle.getString("SELECTED_DATE")
                        tvPickDate.text = date
                        tanggal = date.toString()
                    }
                }
                //show
                datePickerFragment.show(supportFragmentManager, "DatePickerFragment")
            }

            btnPickDate2.setOnClickListener {
                val datePickerFragment = DatePickerFragment()
                val supportFragmentManager = requireActivity().supportFragmentManager

                supportFragmentManager.setFragmentResultListener(
                    "REQUEST_KEY",
                    viewLifecycleOwner
                )
                { resultKey, bundle ->
                    if (resultKey == "REQUEST_KEY") {
                        val date = bundle.getString("SELECTED_DATE")
                        tvPickDate2.text = date
                        /*if (resultKey.isEmpty()){
                            Toast.makeText(activity, "Tanggal harus diisi", Toast.LENGTH_SHORT).show()
                        } else {
                            val date = bundle.getString("SELECTED_DATE")
                            tvPickDate2.text = date
                        }*/
                    }
                }

                //show
                datePickerFragment.show(supportFragmentManager, "DatePickerFragment")

            }

            increment.setOnClickListener {
                if (jmlPenumpang <= 9) {
                    jmlPenumpang++
                    tvPenumpang.text = jmlPenumpang.toString()
                }else{
                    Toast.makeText(activity, "jumlah penumpang maksimal 10 orang", Toast.LENGTH_SHORT).show()
                }
            }

            decrement.setOnClickListener {
                if (jmlPenumpang >= 2) {
                    jmlPenumpang--
                    tvPenumpang.text = jmlPenumpang.toString()
                }else{
                    Toast.makeText(activity, "jumlah penumpang minimal 1 orang", Toast.LENGTH_SHORT).show()
                }
            }

            //process switch pulang pergi
            switch1.setOnCheckedChangeListener { compoundButton, onSwitch ->
                //if else nya disini
                if (onSwitch) {
                    relative3.visibility = View.VISIBLE
                }else {
                    relative3.visibility = View.GONE
                }
            }

            btnCariTiket.setOnClickListener {
                if(validateForm(arrayListOf(tujuan, rute, tanggal, jmlPenumpang.toString()))){
                    val bundle = Bundle()

                    bundle.putString("rute", tujuan)
                    bundle.putString("key", rute)
                    bundle.putString("tanggal", tanggal)
                    bundle.putInt("jmlPenumpang", jmlPenumpang)

                    val newFragment = ListTiket()
                    newFragment.arguments = bundle

                    parentFragmentManager.beginTransaction().add(R.id.container, newFragment).commit()
                }
                else{
                    Toast.makeText(activity, "Mohon lengkapi data terlebih dahulu", Toast.LENGTH_SHORT).show()
                }

            }
        }
    }

    private fun validateForm(data: ArrayList<String>): Boolean {
        data.forEachIndexed{ i, item ->
            if (item == ""){
                return false
            }
        }
        return true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


}




