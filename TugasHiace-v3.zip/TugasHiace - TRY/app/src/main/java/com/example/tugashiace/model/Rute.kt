package com.example.tugashiace.model

data class Rute (
    var State:String?=null,
    val Duration:String?=null,
    val Address:String?=null,
    val Fee:String?=null,
    val Key:String?=null
)