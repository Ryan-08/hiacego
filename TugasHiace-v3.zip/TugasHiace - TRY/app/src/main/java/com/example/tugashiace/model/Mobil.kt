package com.example.tugashiace.model

data class Mobil(
    var Travel : String ?= null,
    var Jadwal : ArrayList<String> ?= null,
    var Rute : ArrayList<String> ?= null,
)
