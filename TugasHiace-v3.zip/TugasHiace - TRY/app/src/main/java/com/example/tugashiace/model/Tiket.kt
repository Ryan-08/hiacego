package com.example.tugashiace.model


data class Tiket(
    val uid : String ?= null,
    val nama : String ?= null,
    val alamat : String ?= null,
    val rute : String ?= null,
    val noHp : String ?= null,
    val tujuan : String ?= null,
    val travel : String ?= null,
    val jam : String ?= null,
    val noKursi : Int ?= null,
    val tanggal : String ?= null,
    val noTiket : String ?= null,
    val status : String ?= null,
    val harga : String ?= null,

)
