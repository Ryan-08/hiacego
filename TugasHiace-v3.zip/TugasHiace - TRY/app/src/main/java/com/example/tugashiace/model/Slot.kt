package com.example.tugashiace.model

data class Slot(
    val Key:String?=null,
    val AvailableSlot:ArrayList<Boolean> ?= null
)
